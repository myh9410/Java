package arrayex;

/*
 */
public class ArrayTest5_1 {

	public static void main(String[] args) {
		int [][] arr = {
				{ 10, 20, 30 },   
				{ 11, 21, 31 },
				{ 12, 22, 32 },
				{ 13, 23, 33 }
		};

		//int rowHap = 0;  �Ҹ��ϴ�.
		for(int j=0; j<4; j++){
			
			int rowHap = 0;  //�����ϴ�.
			
			for(int i=0; i<3; i++){
				System.out.println("arr�� "+j+"�� ���(��) �߿� "+i+"�� ĭ : " + arr[j][i]);
				rowHap += arr[j][i];
			}
			System.out.println("�� �� : " + rowHap);
			System.out.println("---------------------------------");

		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}








