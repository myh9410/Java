package listex;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

/*
	String <-- �˻�  contains() , indexOf
	   	   <-- ����  substring(A, B)
	
	ArrayList (*)
		
 */
public class ArrayListTest {

	public static void main(String[] args) {
		ArrayList<Integer> listA = new ArrayList<Integer>();
		listA.add(10);	// 0��
		listA.add(20);  // 1��
		listA.add(30);
		listA.add(40);
		listA.add(50);	// 4��
		listA.add(60);  // 5��
		System.out.println(listA);
		
		//listB��  listA���� 20, 30, 40 �� ������ ���� �ʱ�ȭ �� �Ŵ�!
		/*List<Integer> list = listA.subList(listA.indexOf(20), listA.indexOf(40)+1);
		System.out.println(list);
		
		ArrayList<Integer> listB = new ArrayList<Integer>(list);
		System.out.println("listB : "+listB);*/
		
		int searchA = Integer.parseInt(JOptionPane.showInputDialog("��� �Է�"));
		int searchB = Integer.parseInt(JOptionPane.showInputDialog("��� �Է�"));
		if(listA.contains(searchA) && listA.contains(searchB)){
			List<Integer> list = listA.subList(listA.indexOf(searchA), listA.indexOf(searchB)+1);
			System.out.println(list);
			
			ArrayList<Integer> listB = new ArrayList<Integer>(list);
			System.out.println("listB : "+listB);
		}else{
			System.out.println("ã������ ��Ұ� �����~");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}









