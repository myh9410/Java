package extendsex;

class Emp{
	String name;
	String address;
	public Emp(String name, String address) {
		this.name = name;
		this.address = address;
	}
	void printEmpInfo(){
		System.out.println("�̸� : "+name);
		System.out.println("�ּ� : "+address);
	}
}

class Regular extends Emp{
	int month;	//�ٹ� ������
	int salary;	//�޿�
	public Regular(String name, String address, int month, int salary) {
		super(name, address);
		this.month = month;
		this.salary = salary;
	}
	private int getSalaryMonthly(){
		return month * salary;
	}
	public void printReg(){
		printEmpInfo();
		
		System.out.println("�޿�("+month+"����) : "+getSalaryMonthly()+"��");
	}
}
class PartTime extends Emp{
	int hour;
	int hourMoney;
	public PartTime(String name, String address, int hour, int hourMoney) {
		super(name, address);
		this.hour = hour;
		this.hourMoney = hourMoney;
	}
	void showMoney(){
		printEmpInfo();
		System.out.println("���ɾ� : "+(hour*(hourMoney))+"��");
	}
}

public class EmpMain {

	public static void main(String[] args) {
		Regular hgd = new Regular("ȫ�浿", "������", 3, 400);
		hgd.printReg();
		
		PartTime kkc = new PartTime("������", "������", 36, 6500);
		kkc.showMoney();
		
		new MyFrame();
		
		
	}

}
