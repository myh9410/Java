package extendsex;
class Date{
	private int year, month, day;
	
	
	public Date(int year, int month, int day) {
		super();
		this.year = year;
		this.month = month;
		this.day = day;
	}


	public int getYear() {
		return year;
	}


	public int getMonth() {
		return month;
	}


	public int getDay() {
		return day;
	}
	
}
class Clock extends Date{
	Clock(){
		super(-1, -1, -1);
	}
}
class Time extends Date{
	//Date.year Date.month  Date.day
	int hour, min, sec;

	public Time(int year, int month, int day, int hour, int min, int sec) {
		//�θ�� ���� �ʱ�ȭ �ϰ�  �ڽ��� ���� ������!
		super(year, month, day);
		
		this.hour = hour;
		this.min = min;
		this.sec = sec;
	}
	
	void printTime(){
		//System.out.println(year+"�� "+month+"�� "+day+"�� "+hour+":"+min+":"+sec);
		System.out.println(getYear()+"�� "+getMonth()+"�� "+getDay()+"�� "
								+hour+":"+min+":"+sec);
	}
}
public class InitializeTest {

	public static void main(String[] args) {
		Time dateAndTime = new Time(2017, 2, 21, 1, 26, 30);
		dateAndTime.printTime();
		

	}

}
