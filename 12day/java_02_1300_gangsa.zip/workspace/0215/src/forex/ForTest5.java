package forex;
/*
	������
	
	
 */
public class ForTest5 {

	public static void main(String[] args) {
		int sum = 0;
		
		sum = sum + 1;	//sum -> 0 -->  1�� �ȴ�

		sum = sum + 1;  //sum : 1  -->  2��..

		sum = sum + 1;
		
		sum = sum + 1;
		
		System.out.println(sum);  //4
		
		
	}
		

}










