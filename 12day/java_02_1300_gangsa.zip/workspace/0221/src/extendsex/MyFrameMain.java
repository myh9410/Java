package extendsex;

import java.awt.Color;

public class MyFrameMain {

	public static void main(String[] args) {
		MyFrame fr  = new MyFrame();
		
		fr.setBackground(Color.CYAN);
		
	}

}
