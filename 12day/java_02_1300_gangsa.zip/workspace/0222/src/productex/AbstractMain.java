package productex;

abstract class ProductItem{
	String type;	//tv?,  radio?  
	String brand;
	int price;

	public ProductItem(String type, String brand, int price) {
		this.type = type;
		this.brand = brand;
		this.price = price;
	}
	
	void printInfo(){
		System.out.println(type+" : "+brand+"("+price+"��)");
	}
	abstract void manual(); //�߻� �޼���
	
}

class Mp3 extends ProductItem{

	public Mp3(String type, String brand, int price) {
		super(type, brand, price);
	}

	@Override
	void manual() {
		System.out.println("MP3 ��ǰ ������");
		
	}
}
class RadioTV extends ProductItem{

	public RadioTV(String type, String brand, int price) {
		super(type, brand, price);
		// TODO Auto-generated constructor stub
	}
	@Override
	void manual() {
		System.out.println("���̴� ���̿� TV ��ǰ ������ �Դϴ�.");
	}
	
}
class Desk extends ProductItem{

	public Desk(String type, String brand, int price) {
		super(type, brand, price);
	}
	@Override
	void manual() {
		System.out.println("DESK");
	}
}
class UseProduct{

	void useful(ProductItem item){
		item.manual();
	}
}

public class AbstractMain {

	public static void main(String[] args) {
		
		UseProduct use = new UseProduct();  //��ǰ�� ����ϱ� ���� Ŭ����!
		use.useful(new Mp3("mp3", "���̸���", 300));
		use.useful(new Desk("����ũž", "dell", 1500));
		use.useful(new RadioTV("���� TV", "�伺", 1900));
		
		
		
		
		
		
		

	}

}




