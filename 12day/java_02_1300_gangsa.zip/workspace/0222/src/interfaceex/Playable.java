package interfaceex;

public interface Playable {
	public void play();
	public void stop();
	public void pause();
}
