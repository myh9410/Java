package innerex2;
/*
	��{
		��
		�� 
		��
	}
	Face{
		int baseColor = 123;
	
		class Eye{ int eyeLen, eyeH, eyeW, color=baseColor;  �޼���(); �޼���(); }
		class Nose{int nLen, nH, nW, nColor=baseColor;}
		class Mouth{ int mLen, mW, mColor=baseColor; }
	}
 */
class Face{
	int faceColor=0xFF0001;
	
	class Eye{
		int eyeColor = faceColor;
		public Eye() {}
		public Eye(int userColor) {
			eyeColor=userColor;
		}
	}
	class Nose{
		int noseColor = faceColor;
	}
	class Mouth{
		int mouthColor = faceColor;
	}
}
public class FaceMain {

	public static void main(String[] args) {
		//�� ����  
		//��, ��, ��
		Face hgd = new Face();
		Face.Eye hEye = hgd.new Eye();
		System.out.println("�� : " + hgd.faceColor);
		System.out.println("�� : " + hEye.eyeColor);
		System.out.println("�� : " + hgd.new Nose().noseColor);
		System.out.println("�� : " + hgd.new Mouth().mouthColor);
		hgd.faceColor = 5555;
		System.out.println("�� : " + hgd.faceColor);
		System.out.println("�� : " + hgd.new Eye().eyeColor);
		System.out.println("�� : " + hgd.new Nose().noseColor);
		System.out.println("�� : " + hgd.new Mouth().mouthColor);
		
		

	}

}




